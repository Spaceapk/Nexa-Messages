# Prueba manual pendiente en Android con SIM

- Instalar debug; verificar permisos denegados y concedidos, rol SMS y cambio posterior a otra app.
- Configurar SIM SMS predeterminada; importar conversaciones sin duplicarlas al reabrir.
- Enviar texto corto, texto largo y Unicode. Confirmar en otro teléfono. Desactivar radio y verificar fallo real.
- Recibir mensajes con app abierta, cerrada y proceso detenido por Android; verificar un único SMS en proveedor y Room.
- Probar respuestas desde notificación y desde llamada, con bloqueo de pantalla y proceso cerrado; comprobar errores sin perder el texto original.
- Abrir enlaces sms/smsto sin envío automático. Contactos solo con permiso.
- Abrir conversación: lectura y cancelación de notificación; confirmar eliminación en historial Android.
- Cambiar Google/iOS, colores, tamaño y cada apariencia, incluido oscuro del sistema.
- Verificar aviso explícito de MMS pendiente. No usar esta alpha como app habitual si se necesitan MMS.
- Actualizar con la misma firma y verificar conservación de mensajes; no usar una clave distinta como actualización.

No marcar estos casos como aprobados sin ejecutarlos en dispositivo o emulador adecuado.

## Dual SIM 0.1.1

- Actualizar sobre 0.1.0 sin desinstalar y comprobar mensajes existentes.
- Conceder y denegar permiso Teléfono desde el selector; regresar desde permisos de Android y verificar actualización de la lista.
- Elegir SIM 1 en ajustes y enviar SMS; elegir SIM 2 dentro del mismo chat y enviar otro. Verificar en el teléfono receptor los dos números reales.
- Cerrar/reabrir y reiniciar el teléfono: comprobar elección general y por conversación.
- Responder desde notificación y desde llamada; comprobar que se respeta la SIM del chat o la elección general.
- Desactivar o retirar la SIM elegida: el siguiente envío debe fallar sin pasar a otra SIM.
- Android con «Preguntar siempre», dos tarjetas activas y sin SIM general explícita: pedir selección; con una sola tarjeta activa, usarla.
- Comprobar Google e iOS y que el selector no tape el texto al abrir teclado.
