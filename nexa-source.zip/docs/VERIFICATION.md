# Nexa Messages 0.1.1-alpha — verificación

Paquete org.nexlibre.nexamessages. versionCode 2. Android 8+ (minSdk 26), targetSdk 35.

Compilación local: `gradle testDebugUnitTest lintDebug assembleDebug`, JDK 17, Gradle 8.9: BUILD SUCCESSFUL.
13 pruebas aprobadas: 8 de selección de SIM y 5 de estados SMS. Lint sin errores; los avisos de versiones de dependencias se conservan en verification/.

APK SHA-256: bcd6af79bbaf1cbeb70c035787ddd92e526c1809dfa95c3ce6d57dc0a32472bf
Firma v2 válida y misma huella del certificado debug que la APK 0.1.0-alpha entregada. Alineación zipalign correcta. Se puede instalar como actualización de esa APK sin desinstalar.

La selección se guarda en DataStore por ID de suscripción; la preferencia del chat prevalece sobre la general. El repositorio de envío compartido también aplica esta política a respuestas rápidas. Se revalida la SIM activa al enviar y se bloquea una elección inválida sin cambiar a otra SIM.

No hay prueba en dispositivo/emulador ni envío real con dos SIM en este entorno. Los casos manuales están en docs/DEVICE-TESTS.md. No se da por probada la entrega por operadora.

Publicación GitHub en proceso mediante la sesión de navegador autorizada; el resultado remoto se verificará antes de afirmarlo. Los informes locales corresponden a esta APK.
