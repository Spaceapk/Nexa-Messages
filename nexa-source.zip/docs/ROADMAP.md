# Continuación

1. Validar SMS en dispositivo físico: rol, permisos, SIM, callbacks, notificaciones, enlaces, lectura y borrado; corregir lo que falle. Añadir pruebas instrumentadas Room y recepción de SMS en emulador. Optimizar importación con ContentObserver y reconciliación con el proveedor; selector multi-SIM y recuperación de envíos pendientes.
2. MMS: elegir una biblioteca mantenida o implementar PDUs con pruebas APN; descarga autenticada por operadora, adjuntos, límites y reintentos. No añadir botones multimedia hasta que exista transporte real. Garantizar que cambiar de app predeterminada no provoque pérdida de MMS.
3. Exportación y restauración cifradas mediante Storage Access Framework, confirmación y política de retención. No activar backup de datos privados sin diseño y consentimiento.
4. Mensajería por Internet: acordar alojamiento y coste, protocolo, registro y recuperación de cuenta. Evaluar una implementación mantenida de Signal o MLS con revisión especializada; no inventar criptografía. Directorio, claves, dispositivos, colas offline y notificaciones push. Servidor elegido y configurado es requisito para una entrega real.
5. Adjuntos cifrados, notas de voz, grupos, respuestas, reacciones, stickers/GIF con proveedor real y privacidad explícita. Mensajes temporales y programación con límites claros de entrega y borrado.
6. Voz y vídeo con WebRTC, señalización autenticada y TURN desplegado. Validar llamadas en segundo plano y consumo.
7. Firma permanente protegida y reproducibilidad; APK release verificable, controles de seguridad y pruebas físicas antes de publicar estable.

No hay infraestructura contratada, credenciales ni servidor de Nexa en esta entrega.
