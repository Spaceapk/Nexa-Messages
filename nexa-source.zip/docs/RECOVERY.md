# Recuperación del PDF

Origen: Nexa Messages — Proyecto Nativo Android, paquete org.nexlibre.nexamessages, 49 páginas. Leído íntegramente. Recuperados 18 bloques Kotlin, manifiesto y Gradle de app. El bloque que contenía MmsReceiver y HeadlessSmsSendService se separó en archivos.

Se conservaron modelos, pantallas, DataStore, Room, temas y navegación válidos. Se repararon líneas truncadas en contactos, ViewModel y pantallas; importaciones Color y lifecycle-runtime-compose; expresiones de colores e iconos. Se añadieron Gradle raíz, settings, recursos, wrapper, reglas y CI. Se eliminaron las migraciones destructivas y el backup automático de SMS.

La afirmación del PDF “100 % operativas” no era evidencia de compilación ni de prueba en dispositivo. No implementaba notificaciones, solicitud real del rol SMS, persistencia en el proveedor Android ni callbacks; MMS y el servicio eran componentes vacíos.

Cambios: recepción solo SMS_DELIVER; guardado tanto en proveedor Android como Room; sincronización inicial incremental por ID; callbacks persistidos y reducidos por partes; permisos y selección del rol; notificaciones, respuesta y enlaces SMS; borrado confirmado. El proveedor Android sigue siendo necesario para interoperabilidad.

Limitaciones: MMS real pendiente. No se simulan transportes Internet ni cifrado. No hay pruebas con SIM en este entorno. No se garantiza comportamiento de servicios background en todos los fabricantes. La importación consulta el historial completo en cada reanudación, con deduplicación en Room; optimizar para historiales grandes. Borrados externos y cambios de estado externos no se sincronizan todavía.

Se añadió búsqueda directa PhoneLookup al recibir mensajes, captura de fallos en receptores, soporte de intenciones de conversación y borradores que no se vacían ante un rechazo inmediato del transporte. Las reglas Android 12+ excluyen los datos de copias y transferencias automáticas. El primer análisis lint detectó una llamada de API 29 incompatible con minSdk 26; se sustituyó por una comparación del identificador de suscripción.
