package org.nexlibre.nexamessages.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.*
import org.nexlibre.nexamessages.notifications.SmsNotifications

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.provider.Telephony.WAP_PUSH_DELIVER") return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { SmsNotifications.show(context, 0, "MMS pendiente", "Esta versión no descarga MMS. Usa una aplicación compatible para multimedia de tu operadora.") }
            finally { pending.finish() }
        }
    }
}
