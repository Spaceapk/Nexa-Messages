package org.nexlibre.nexamessages.data.repository

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import org.nexlibre.nexamessages.domain.model.SimCard

class SimRepository(private val context: Context) {
    fun loadActiveSims(): List<SimCard>? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return null
        return context.getSystemService(SubscriptionManager::class.java)?.activeSubscriptionInfoList.orEmpty()
            .filter { it.simSlotIndex >= 0 }
            .sortedBy { it.simSlotIndex }
            .map { SimCard(it.subscriptionId, it.simSlotIndex, it.displayName?.toString().orEmpty().ifBlank { "Tarjeta SIM" }) }
    }
}
