package org.nexlibre.nexamessages.domain.model

enum class UiStyle(val label: String) {
    GOOGLE("Google (Material Design 3)"),
    IOS("iOS (Clásico Sólido)")
}

enum class AppearanceMode(val label: String) {
    LIGHT("Claro"),
    AMOLED_DARK("Oscuro AMOLED (#000000)"),
    SYSTEM("Seguir sistema")
}

enum class AccentPreset(val label: String, val hexColor: Long) {
    NEXA_BLUE("Azul Nexa / iMessage", 0xFF007AFF),
    EMERALD("Verde Esmeralda", 0xFF10B981),
    INDIGO("Índigo Profundo", 0xFF4F46E5),
    CORAL("Coral Intenso", 0xFFE11D48),
    TEAL("Turquesa Sobrio", 0xFF0D9488)
}

enum class ChatBackgroundPreset(
    val label: String,
    val lightHex: Long,
    val darkHex: Long
) {
    DEFAULT("Predeterminado del estilo", 0xFFFFFFFF, 0xFF000000),
    WARM_PAPER("Papel Cálido / Pizarra", 0xFFF7F4EF, 0xFF0D0D0D),
    SOFT_SAGE("Salvia Suave / Grafito", 0xFFEEF5F0, 0xFF080E0A),
    NORDIC_BLUE("Azul Nórdico / Noche", 0xFFEEF3F8, 0xFF070B10)
}

data class UserSettings(
    val uiStyle: UiStyle = UiStyle.GOOGLE,
    val appearanceMode: AppearanceMode = AppearanceMode.SYSTEM,
    val useDynamicColors: Boolean = true,
    val accentPreset: AccentPreset = AccentPreset.NEXA_BLUE,
    val chatBackground: ChatBackgroundPreset = ChatBackgroundPreset.DEFAULT,
    val fontScale: Float = 1.0f,
    val notificationsEnabled: Boolean = true,
    val previewInNotifications: Boolean = true,
    val preferredSmsSubscriptionId: Int = SIM_SYSTEM
)

data class ContactItem(
    val id: String,
    val name: String,
    val phoneNumber: String
)
