package org.nexlibre.nexamessages.receiver

import android.app.Service
import android.content.Intent
import android.os.IBinder
import kotlinx.coroutines.*
import org.nexlibre.nexamessages.data.local.NexaDatabase
import org.nexlibre.nexamessages.data.repository.*
import org.nexlibre.nexamessages.notifications.SmsNotifications

class HeadlessSmsSendService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val address = intent?.data?.schemeSpecificPart?.substringBefore('?')
        val body = intent?.getStringExtra(Intent.EXTRA_TEXT)
        if (intent?.action != "android.intent.action.RESPOND_VIA_MESSAGE" || address.isNullOrBlank() || body.isNullOrBlank()) {
            stopSelf(startId); return START_NOT_STICKY
        }
        scope.launch {
            try {
                val repo = MessagingRepository(applicationContext, NexaDatabase.getInstance(this@HeadlessSmsSendService).nexaDao(), ContactsHelper(applicationContext))
                val id = repo.getOrCreateConversation(address)
                repo.sendSmsMessage(id, address, body).onFailure {
                    SmsNotifications.show(applicationContext, id, address, "No se pudo enviar la respuesta: ${it.message}")
                }
            } catch (error: Exception) {
                android.util.Log.e("NexaSMS", "SMS processing failed", error)
            } finally { stopSelf(startId) }
        }
        return START_NOT_STICKY
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
