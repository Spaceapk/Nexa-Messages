package org.nexlibre.nexamessages.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.nexlibre.nexamessages.domain.model.*

@Composable
fun SimSelector(selected: Int, sims: List<SimCard>, onSelect: (Int) -> Unit, onRefresh: () -> Unit,
                allowInherit: Boolean = false, globalSelection: Int = SIM_SYSTEM) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    fun permitted() = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
    var hasPermission by remember { mutableStateOf(permitted()) }
    var expanded by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted; denied = !granted; onRefresh()
    }
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) { hasPermission = permitted(); onRefresh() }
        }
        lifecycle.addObserver(observer)
        hasPermission = permitted(); onRefresh()
        onDispose { lifecycle.removeObserver(observer) }
    }
    fun label(id: Int): String = when (id) {
        SIM_SYSTEM -> "Predeterminada de Android"
        SIM_INHERIT -> "Usar ajuste general · ${sims.firstOrNull { it.subscriptionId == globalSelection }?.label ?: if(globalSelection == SIM_SYSTEM) "Android" else "SIM no disponible"}"
        else -> sims.firstOrNull { it.subscriptionId == id }?.label ?: "SIM elegida no disponible"
    }
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
        Text("SIM para enviar SMS", style = MaterialTheme.typography.labelMedium)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(label(selected)) }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                if (allowInherit) DropdownMenuItem(text = { Text(label(SIM_INHERIT)) }, onClick = { onSelect(SIM_INHERIT); expanded = false })
                DropdownMenuItem(text = { Text("Predeterminada de Android") }, onClick = { onSelect(SIM_SYSTEM); expanded = false })
                sims.forEach { sim ->
                    DropdownMenuItem(text = { Text(sim.label) }, onClick = { onSelect(sim.subscriptionId); expanded = false })
                }
            }
        }
        if (!hasPermission) {
            Text("Permite acceso al teléfono para mostrar y elegir tus SIM.", style = MaterialTheme.typography.bodySmall)
            TextButton(onClick = { permission.launch(Manifest.permission.READ_PHONE_STATE) }) { Text("Mostrar SIM 1 y SIM 2") }
            if (denied) TextButton(onClick = {
                context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
            }) { Text("Abrir permisos de la aplicación") }
        } else if (sims.isEmpty()) Text("No hay SIM activas. Revisa las tarjetas en los ajustes de Android.", style = MaterialTheme.typography.bodySmall)
        if (selected >= 0 && sims.none { it.subscriptionId == selected }) Text("Selecciona otra SIM antes de enviar.", color = MaterialTheme.colorScheme.error)
    }
}
