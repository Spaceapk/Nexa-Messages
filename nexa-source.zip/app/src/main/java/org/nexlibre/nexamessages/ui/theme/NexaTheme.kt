package org.nexlibre.nexamessages.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.domain.model.AppearanceMode
import org.nexlibre.nexamessages.domain.model.UiStyle
import org.nexlibre.nexamessages.domain.model.UserSettings

data class NexaStyleTokens(
    val uiStyle: UiStyle,
    val isDark: Boolean,
    val cardCornerRadius: Dp,
    val incomingBubbleColor: Color,
    val incomingTextColor: Color,
    val outgoingBubbleColor: Color,
    val outgoingTextColor: Color,
    val chatCanvasBackground: Color,
    val useDividersInsteadOfCards: Boolean
)

val LocalNexaStyle = staticCompositionLocalOf {
    NexaStyleTokens(
        uiStyle = UiStyle.GOOGLE,
        isDark = false,
        cardCornerRadius = 24.dp,
        incomingBubbleColor = Color(0xFFE9E9EB),
        incomingTextColor = Color(0xFF111111),
        outgoingBubbleColor = Color(0xFF007AFF),
        outgoingTextColor = Color.White,
        chatCanvasBackground = Color.White,
        useDividersInsteadOfCards = false
    )
}

@Composable
fun NexaTheme(
    settings: UserSettings,
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()

   val isDark = when (settings.appearanceMode) {
       AppearanceMode.LIGHT -> false
       AppearanceMode.AMOLED_DARK -> true
       AppearanceMode.SYSTEM -> systemDark
   }

   val accentColor = Color(settings.accentPreset.hexColor)

// Selección del esquema de color Material 3
val baseColorScheme = when {
    settings.uiStyle == UiStyle.GOOGLE &&
        settings.useDynamicColors &&
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        if (isDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    isDark -> darkColorScheme(
        primary = accentColor,
        onPrimary = Color.White,
        primaryContainer = accentColor.copy(alpha = 0.25f),
        onPrimaryContainer = Color.White,
        secondary = accentColor,
        background = Color(0xFF000000), // Negro puro AMOLED
        onBackground = Color(0xFFF5F5F7),
        surface = Color(0xFF000000),    // Negro puro AMOLED
        onSurface = Color(0xFFF5F5F7),
        surfaceVariant = Color(0xFF161618),
        onSurfaceVariant = Color(0xFFAEAEB2)
    )
    else -> lightColorScheme(
        primary = accentColor,
        onPrimary = Color.White,
        primaryContainer = accentColor.copy(alpha = 0.14f),
        onPrimaryContainer = accentColor,
        secondary = accentColor,
        background = if (settings.uiStyle == UiStyle.IOS) Color.White else Color(0xFFF8F9FA),
        onBackground = Color(0xFF111111),
        surface = Color.White,
        onSurface = Color(0xFF111111),
        surfaceVariant = if (settings.uiStyle == UiStyle.IOS) Color(0xFFF2F2F7) else Color(0xFFEFF1F5),
        onSurfaceVariant = Color(0xFF5E5E66)
    )
}

// Forzar negro puro #000000 si está activo el modo Oscuro (incluso con colores dinámicos)
val finalColorScheme = if (isDark) {
    baseColorScheme.copy(
        background = Color(0xFF000000),
        surface = Color(0xFF000000),
        surfaceContainer = Color(0xFF121214),
        surfaceContainerHigh = Color(0xFF1C1C1E)
    )
} else {
    baseColorScheme
}

// Tokens específicos para diferenciar Google Material 3 vs iOS Clásico Sólido
val chatBgColor = if (isDark) {
    Color(settings.chatBackground.darkHex)
} else {
    Color(settings.chatBackground.lightHex)
}

val styleTokens = if (settings.uiStyle == UiStyle.IOS) {
    NexaStyleTokens(
        uiStyle = UiStyle.IOS,
        isDark = isDark,
        cardCornerRadius = 12.dp,
        incomingBubbleColor = if (isDark) Color(0xFF262629) else Color(0xFFE9E9EB),
        incomingTextColor = if (isDark) Color.White else Color.Black,

           outgoingBubbleColor = accentColor,
           outgoingTextColor = Color.White,
           chatCanvasBackground = chatBgColor,
           useDividersInsteadOfCards = true
        )
    } else {
        NexaStyleTokens(
            uiStyle = UiStyle.GOOGLE,
            isDark = isDark,
            cardCornerRadius = 24.dp,
            incomingBubbleColor = if (isDark) Color(0xFF1E1F22) else finalColorScheme.surfaceVariant,
            incomingTextColor = finalColorScheme.onSurface,
            outgoingBubbleColor = finalColorScheme.primary,
            outgoingTextColor = finalColorScheme.onPrimary,
            chatCanvasBackground = chatBgColor,
            useDividersInsteadOfCards = false
        )
    }

    val currentDensity = LocalDensity.current
    val scaledDensity = Density(
        density = currentDensity.density,
        fontScale = currentDensity.fontScale * settings.fontScale
    )

    CompositionLocalProvider(
        LocalNexaStyle provides styleTokens,
        LocalDensity provides scaledDensity
    ) {
        MaterialTheme(
            colorScheme = finalColorScheme,
            shapes = Shapes(
                small = RoundedCornerShape(if (settings.uiStyle == UiStyle.IOS) 8.dp else 12.dp),
                medium = RoundedCornerShape(if (settings.uiStyle == UiStyle.IOS) 12.dp else 20.dp),
                large = RoundedCornerShape(if (settings.uiStyle == UiStyle.IOS) 18.dp else 28.dp)
            ),
            content = content
        )
    }
}
