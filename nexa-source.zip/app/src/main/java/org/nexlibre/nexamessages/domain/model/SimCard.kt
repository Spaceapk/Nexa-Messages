package org.nexlibre.nexamessages.domain.model

data class SimCard(val subscriptionId: Int, val slotIndex: Int, val displayName: String) {
    val label: String get() = "SIM ${slotIndex + 1} · $displayName"
}
const val SIM_SYSTEM = -1
const val SIM_INHERIT = -2

fun resolveSmsSubscription(preferred: Int, systemDefault: Int, active: List<Int>?): Int {
    fun valid(id: Int) = id >= 0 && id != Int.MAX_VALUE
    if (preferred != SIM_SYSTEM) {
        check(valid(preferred) && active != null && preferred in active) {
            "La SIM elegida no está disponible. Revisa el permiso de teléfono y selecciona una SIM activa."
        }
        return preferred
    }
    if (valid(systemDefault) && (active == null || systemDefault in active)) return systemDefault
    if (active?.size == 1) return active.single()
    error("Elige SIM 1 o SIM 2 antes de enviar el SMS.")
}
