package org.nexlibre.nexamessages.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ConversationEntity::class, MessageEntity::class, SmsPartResult::class],
    version = 1,
    exportSchema = false
)
abstract class NexaDatabase : RoomDatabase() {

     abstract fun nexaDao(): NexaDao

     companion object {
         @Volatile
         private var INSTANCE: NexaDatabase? = null

          fun getInstance(context: Context): NexaDatabase {
              return INSTANCE ?: synchronized(this) {
                  Room.databaseBuilder(
                      context.applicationContext,
                      NexaDatabase::class.java,
                      "nexa_messages.db"
                  )
                      .build()
                      .also { INSTANCE = it }
              }
          }
     }
}
