package org.nexlibre.nexamessages.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class MessageStatus {
    SENDING, SENT, DELIVERED, FAILED, RECEIVED
}

enum class MessageTransport {
    SMS, MMS
}

@Entity(
    tableName = "conversations",
    indices = [Index(value = ["address"], unique = true)]
)
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val address: String,
    val contactName: String?,
    val lastMessagePreview: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false
)

@Entity(
    tableName = "messages",
    foreignKeys = [
        ForeignKey(
            entity = ConversationEntity::class,
            parentColumns = ["id"],
            childColumns = ["conversationId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["conversationId"]), Index(value = ["providerId"], unique = true)]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val senderAddress: String,
    val body: String,
    val timestamp: Long,
    val isIncoming: Boolean,
    val status: MessageStatus,
    val transport: MessageTransport = MessageTransport.SMS,
    // Campos preparados para futuras fases (respuestas, ediciones, adjuntos)
    val replyToMessageId: Long? = null,
    val attachmentUri: String? = null,
    val attachmentMimeType: String? = null,
    val providerId: Long? = null,
    val partCount: Int = 1
)

@Entity(tableName = "sms_results", primaryKeys = ["messageId", "kind", "part"])
data class SmsPartResult(val messageId: Long, val kind: String, val part: Int, val success: Boolean)
