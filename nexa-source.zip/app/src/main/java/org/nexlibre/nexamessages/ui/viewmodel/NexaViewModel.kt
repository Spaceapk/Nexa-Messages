package org.nexlibre.nexamessages.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.nexlibre.nexamessages.data.local.ConversationEntity
import org.nexlibre.nexamessages.data.local.MessageEntity
import org.nexlibre.nexamessages.data.local.NexaDatabase
import org.nexlibre.nexamessages.data.preferences.SettingsDataStore
import org.nexlibre.nexamessages.data.repository.ContactsHelper
import org.nexlibre.nexamessages.data.repository.MessagingRepository
import org.nexlibre.nexamessages.domain.model.*

@OptIn(ExperimentalCoroutinesApi::class)
class NexaViewModel(application: Application) : AndroidViewModel(application) {

   private val database = NexaDatabase.getInstance(application)
   private val contactsHelper = ContactsHelper(application)
   private val repository = MessagingRepository(application, database.nexaDao(), contactsHelper)
   private val settingsStore = SettingsDataStore(application)
   private var simPreferenceWrite: kotlinx.coroutines.Job? = null

   val settings: StateFlow<UserSettings> = settingsStore.settingsFlow.stateIn(
       scope = viewModelScope,
       started = SharingStarted.WhileSubscribed(5000),
       initialValue = UserSettings()
   )

   private val _searchQuery = MutableStateFlow("")
   val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

   val conversations: StateFlow<List<ConversationEntity>> = _searchQuery
       .flatMapLatest { query ->
           if (query.isBlank()) {
               repository.observeConversations()
           } else {
               repository.searchConversations(query.trim())
           }
       }
       .stateIn(
           scope = viewModelScope,
           started = SharingStarted.WhileSubscribed(5000),
           initialValue = emptyList()
       )

   private val _contacts = MutableStateFlow<List<ContactItem>>(emptyList())
   val contacts: StateFlow<List<ContactItem>> = _contacts.asStateFlow()

   private val _statusBanner = MutableStateFlow<String?>(null)
   val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

   fun updateSearchQuery(query: String) {
       _searchQuery.value = query
   }

fun clearStatusBanner() {
    _statusBanner.value = null
}

fun syncSms() {
    viewModelScope.launch { runCatching { repository.syncSms() }.onFailure { _statusBanner.value = it.message } }
}

fun refreshContacts() {
    viewModelScope.launch {
        runCatching { contactsHelper.loadDeviceContacts() }.onSuccess { _contacts.value = it }.onFailure { _statusBanner.value = it.message }
    }
}

fun observeConversation(conversationId: Long): Flow<ConversationEntity?> =
    repository.observeConversation(conversationId)

fun observeMessages(conversationId: Long): Flow<List<MessageEntity>> =
    repository.observeMessages(conversationId)

fun markConversationRead(conversationId: Long) {
    viewModelScope.launch {
        runCatching { repository.markAsRead(conversationId) }.onFailure { _statusBanner.value = it.message }
    }
}

fun startOrOpenConversation(
    address: String,
    contactName: String?,
    initialMessage: String? = null,
    onReady: (Long) -> Unit
) {
    viewModelScope.launch {
        simPreferenceWrite?.join()
        val convId = runCatching { repository.getOrCreateConversation(address, contactName) }.getOrElse {
            _statusBanner.value = it.message
            return@launch
        }
        if (!initialMessage.isNullOrBlank()) {
            val result = repository.sendSmsMessage(convId, address, initialMessage.trim())
            result.onFailure { err ->
                _statusBanner.value = err.localizedMessage ?: "Error al enviar SMS"
                return@launch
            }
        }
        onReady(convId)
    }
}

fun sendSms(conversationId: Long, address: String, body: String, onSubmitted: (Boolean) -> Unit = {}) {
    if (body.isBlank()) return
    viewModelScope.launch {
        simPreferenceWrite?.join()
        val result = repository.sendSmsMessage(conversationId, address, body.trim())
        onSubmitted(result.isSuccess)
        result.onFailure { err ->
            _statusBanner.value = err.localizedMessage
                ?: "No se pudo despachar el SMS por red móvil. Guardado en el historial local."
        }
    }
}

fun deleteConversation(conversationId: Long) {
    viewModelScope.launch {
        runCatching { repository.deleteConversation(conversationId) }.onFailure { _statusBanner.value = it.message }
    }
}

// Acciones de Ajustes
fun setUiStyle(style: UiStyle) = viewModelScope.launch { settingsStore.updateUiStyle(style) }
fun setAppearance(mode: AppearanceMode) = viewModelScope.launch { settingsStore.updateAppearance(mode) }
fun setDynamicColors(enabled: Boolean) = viewModelScope.launch { settingsStore.updateDynamicColors(enabled) }
fun setAccentPreset(preset: AccentPreset) = viewModelScope.launch { settingsStore.updateAccentPreset(preset) }
fun setChatBackground(bg: ChatBackgroundPreset) = viewModelScope.launch { settingsStore.updateChatBackground(bg) }
fun setFontScale(scale: Float) = viewModelScope.launch { settingsStore.updateFontScale(scale) }
fun setNotifications(enabled: Boolean) = viewModelScope.launch { settingsStore.updateNotifications(enabled) }
fun setNotificationPreview(enabled: Boolean) = viewModelScope.launch { settingsStore.updateNotificationPreview(enabled) }

private val _activeSims = MutableStateFlow<List<SimCard>>(emptyList())
val activeSims = _activeSims.asStateFlow()
fun refreshSims() {
    runCatching { org.nexlibre.nexamessages.data.repository.SimRepository(getApplication()).loadActiveSims().orEmpty() }
        .onSuccess { _activeSims.value = it }.onFailure { _statusBanner.value = "No se pudieron consultar las SIM: ${it.message}" }
}
fun observeConversationSim(id: Long) = settingsStore.conversationSimFlow(id)
private fun saveSimPreference(block: suspend () -> Unit) {
    val previous = simPreferenceWrite
    simPreferenceWrite = viewModelScope.launch {
        previous?.join()
        block()
    }
}
fun setPreferredSmsSim(id: Int) = saveSimPreference { settingsStore.setPreferredSmsSim(id) }
fun setConversationSmsSim(conversationId: Long, id: Int) = saveSimPreference { settingsStore.setConversationSmsSim(conversationId, id) }
}
