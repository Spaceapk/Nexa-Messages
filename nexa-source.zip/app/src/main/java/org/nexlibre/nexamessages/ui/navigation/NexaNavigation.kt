package org.nexlibre.nexamessages.ui.navigation

import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import org.nexlibre.nexamessages.ui.screens.*
import org.nexlibre.nexamessages.ui.viewmodel.NexaViewModel

@Composable
fun NexaNavigation(viewModel: NexaViewModel, incomingIntent: android.content.Intent? = null, onIntentConsumed: () -> Unit = {}) {
    val navController = rememberNavController()
    val conversations by viewModel.conversations.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()
    val sims by viewModel.activeSims.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBanner.collectAsStateWithLifecycle()

   var selectedAddressForCompose by remember { mutableStateOf("") }
   var selectedBodyForCompose by remember { mutableStateOf("") }
   var selectedNameForCompose by remember { mutableStateOf<String?>(null) }

   LaunchedEffect(incomingIntent) {
       incomingIntent?.let { intent ->
           val chat = intent.getLongExtra("conversation_id", -1)
           if (chat > 0) navController.navigate("chat/$chat") { launchSingleTop = true }
           else if (intent.action == android.content.Intent.ACTION_SENDTO || intent.data?.scheme in listOf("sms", "smsto", "mms", "mmsto")) {
               selectedAddressForCompose = intent.data?.schemeSpecificPart?.substringBefore('?') ?: ""
               selectedNameForCompose = null
               selectedBodyForCompose = intent.getStringExtra("sms_body") ?: ""
               navController.navigate("compose") { launchSingleTop = true }
           }
           onIntentConsumed()
       }
   }

   NavHost(
       navController = navController,
       startDestination = "conversations"
   ) {
       composable("conversations") {
           ConversationListScreen(
               conversations = conversations,
               searchQuery = searchQuery,
               onSearchQueryChange = viewModel::updateSearchQuery,
               onOpenConversation = { id ->
                   viewModel.markConversationRead(id)
                   navController.navigate("chat/$id")
               },
               onComposeNew = {
                   selectedBodyForCompose = ""
                   selectedAddressForCompose = ""
                   selectedNameForCompose = null
                   navController.navigate("compose")
               },
               onOpenContacts = {
                   navController.navigate("contacts")
               },
               onOpenSettings = {
                   navController.navigate("settings")
               },
               onDeleteConversation = viewModel::deleteConversation
           )
       }

       composable(
           route = "chat/{conversationId}",
           arguments = listOf(navArgument("conversationId") { type = NavType.LongType })
       ) { backStackEntry ->
           val convId = backStackEntry.arguments?.getLong("conversationId") ?: 0L

    val conversation by viewModel.observeConversation(convId)
        .collectAsStateWithLifecycle(initialValue = null)
    val messages by viewModel.observeMessages(convId)
        .collectAsStateWithLifecycle(initialValue = emptyList())

    LaunchedEffect(convId, messages.size) {
        viewModel.markConversationRead(convId)
    }

    val chatSim by viewModel.observeConversationSim(convId).collectAsStateWithLifecycle(initialValue = org.nexlibre.nexamessages.domain.model.SIM_INHERIT)
    ChatScreen(
        simSelector = { SimSelector(chatSim, sims, { viewModel.setConversationSmsSim(convId, it) }, viewModel::refreshSims,
            allowInherit = true, globalSelection = settings.preferredSmsSubscriptionId) },
        conversation = conversation,
        messages = messages,
        statusBanner = statusBanner,
        onDismissBanner = viewModel::clearStatusBanner,
        onSendMessage = { text, onSubmitted ->
            conversation?.address?.let { address ->
                viewModel.sendSms(convId, address, text, onSubmitted)
            }
        },
        onBack = { navController.popBackStack() }
    )
}

composable("compose") {
    ComposeMessageScreen(
        simSelector = { SimSelector(settings.preferredSmsSubscriptionId, sims, { viewModel.setPreferredSmsSim(it) }, viewModel::refreshSims) },
        prefilledAddress = selectedAddressForCompose,
        prefilledBody = selectedBodyForCompose,
        prefilledName = selectedNameForCompose,
        onPickContact = { navController.navigate("contacts") },
        onStartChat = { address, name, initialBody ->
            viewModel.startOrOpenConversation(
                address = address,
                contactName = name,
                initialMessage = initialBody.takeIf { it.isNotBlank() }
            ) { convId ->
                navController.navigate("chat/$convId") {
                    popUpTo("conversations")
                }
            }
        },
        onBack = { navController.popBackStack() }
    )
}

composable("contacts") {
    ContactPickerScreen(
        contacts = contacts,
        onRequestRefreshContacts = viewModel::refreshContacts,
        onSelectContact = { contact ->
            selectedAddressForCompose = contact.phoneNumber
            selectedNameForCompose = contact.name
            navController.navigate("compose") {
                popUpTo("conversations")
            }
        },
        onBack = { navController.popBackStack() }
    )
}

composable("settings") {
    SettingsScreen(
        simSelector = { SimSelector(settings.preferredSmsSubscriptionId, sims, { viewModel.setPreferredSmsSim(it) }, viewModel::refreshSims) },
        settings = settings,

                     onUiStyleChange = viewModel::setUiStyle,
                     onAppearanceChange = viewModel::setAppearance,
                     onDynamicColorsChange = viewModel::setDynamicColors,
                     onAccentPresetChange = viewModel::setAccentPreset,
                     onChatBackgroundChange = viewModel::setChatBackground,
                     onFontScaleChange = viewModel::setFontScale,
                     onNotificationsChange = viewModel::setNotifications,
                     onNotificationPreviewChange = viewModel::setNotificationPreview,
                     onBack = { navController.popBackStack() }
                 )
          }
     }
}
