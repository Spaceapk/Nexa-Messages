package org.nexlibre.nexamessages.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.domain.model.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: UserSettings,
    onUiStyleChange: (UiStyle) -> Unit,
    onAppearanceChange: (AppearanceMode) -> Unit,
    onDynamicColorsChange: (Boolean) -> Unit,
    onAccentPresetChange: (AccentPreset) -> Unit,
    onChatBackgroundChange: (ChatBackgroundPreset) -> Unit,
    onFontScaleChange: (Float) -> Unit,
    onNotificationsChange: (Boolean) -> Unit,
    onNotificationPreviewChange: (Boolean) -> Unit,
    onBack: () -> Unit,
    simSelector: @Composable () -> Unit = {}
) {
    val scrollState = rememberScrollState()

   Scaffold(
       containerColor = MaterialTheme.colorScheme.background,
       topBar = {
           TopAppBar(
               title = { Text("Ajustes de Nexa Messages") },
               navigationIcon = {
                   IconButton(onClick = onBack) {
                       Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                   }
               }
           )
       }
   ) { padding ->
       Column(
           modifier = Modifier
               .fillMaxSize()
               .padding(padding)
               .verticalScroll(scrollState)
               .padding(16.dp),
           verticalArrangement = Arrangement.spacedBy(20.dp)
       ) {
           Text("Versión de prueba SMS. MMS, Internet y llamadas pendientes. Los SMS no tienen cifrado de extremo a extremo. La copia automática de datos está desactivada.", style = MaterialTheme.typography.bodySmall)
           SettingsSectionCard(title = "Tarjetas SIM") { simSelector() }
           // 1. Estilo Visual (Google vs iOS)
           SettingsSectionCard(title = "1. Estilo de Interfaz") {

    UiStyle.entries.forEach { styleOption ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onUiStyleChange(styleOption) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = settings.uiStyle == styleOption,
                onClick = { onUiStyleChange(styleOption) }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(styleOption.label, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

// 2. Apariencia (Claro, Oscuro AMOLED #000000, Sistema)
SettingsSectionCard(title = "2. Apariencia y Modo AMOLED") {
    AppearanceMode.entries.forEach { mode ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onAppearanceChange(mode) }
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = settings.appearanceMode == mode,
                onClick = { onAppearanceChange(mode) }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(mode.label, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

// 3. Colores Dinámicos y Acento
SettingsSectionCard(title = "3. Colores y Fondo de Conversación") {
    if (settings.uiStyle == UiStyle.GOOGLE) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Colores dinámicos (Material You)", fontWeight = FontWeight.Medium)
                Text(
                    "Toma la paleta del fondo de pantalla en Android 12+",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = settings.useDynamicColors,
                onCheckedChange = onDynamicColorsChange
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
    }

    Text("Color de acento personalizado:", fontWeight = FontWeight.Medium)
    Spacer(modifier = Modifier.height(8.dp))
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AccentPreset.entries.forEach { preset ->
            val isSelected = settings.accentPreset == preset
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(preset.hexColor))
                    .border(
                        width = if (isSelected) 3.dp else 0.dp,
                        color = MaterialTheme.colorScheme.onSurface,
                        shape = CircleShape
                    )
                    .clickable { onAccentPresetChange(preset) }
            )
        }
    }

    Spacer(modifier = Modifier.height(16.dp))
    Text("Fondo sólido de conversación:", fontWeight = FontWeight.Medium)
    ChatBackgroundPreset.entries.forEach { bgPreset ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onChatBackgroundChange(bgPreset) }
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = settings.chatBackground == bgPreset,
                onClick = { onChatBackgroundChange(bgPreset) }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(bgPreset.label)
        }
    }
}

// 4. Tamaño de Texto
SettingsSectionCard(title = "4. Tamaño de Texto (${(settings.fontScale * 100).toInt()}%)") {
    Slider(
        value = settings.fontScale,
        onValueChange = onFontScaleChange,
        valueRange = 0.85f..1.35f,
        steps = 4
    )
    Text(
        text = "Vista previa de lectura para burbujas de mensajes SMS y menús.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

// 5. Notificaciones y Privacidad
SettingsSectionCard(title = "5. Notificaciones y Privacidad") {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Notificaciones de mensajes entrantes", Modifier.weight(1f))
                    Switch(
                        checked = settings.notificationsEnabled,
                        onCheckedChange = onNotificationsChange
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mostrar vista previa del mensaje", Modifier.weight(1f))
                    Switch(
                        checked = settings.previewInNotifications,
                        onCheckedChange = onNotificationPreviewChange
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
