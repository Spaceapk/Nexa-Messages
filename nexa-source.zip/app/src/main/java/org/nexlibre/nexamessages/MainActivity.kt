package org.nexlibre.nexamessages

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import org.nexlibre.nexamessages.ui.navigation.NexaNavigation
import org.nexlibre.nexamessages.ui.theme.NexaTheme
import org.nexlibre.nexamessages.ui.viewmodel.NexaViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: NexaViewModel by viewModels()
    private var incomingIntent by mutableStateOf<Intent?>(null)
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); incomingIntent = intent }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        incomingIntent = intent
        enableEdgeToEdge()
        setContent {
            val settings by viewModel.settings.collectAsStateWithLifecycle()
            val status by viewModel.statusBanner.collectAsStateWithLifecycle()
            var isDefault by remember { mutableStateOf(Telephony.Sms.getDefaultSmsPackage(this) == packageName) }
            var hasSms by remember { mutableStateOf(listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS).all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }) }
            val permissions = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                hasSms = listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS).all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }
                viewModel.syncSms(); viewModel.refreshContacts()
            }
            fun requestPermissions() {
                permissions.launch((listOf(Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_MMS, Manifest.permission.RECEIVE_WAP_PUSH) +
                    if(Build.VERSION.SDK_INT >= 33) listOf(Manifest.permission.POST_NOTIFICATIONS) else emptyList()).toTypedArray())
            }
            val role = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
                isDefault = Telephony.Sms.getDefaultSmsPackage(this) == packageName
                if (isDefault) requestPermissions()
            }
            DisposableEffect(Unit) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        isDefault = Telephony.Sms.getDefaultSmsPackage(this@MainActivity) == packageName
                        hasSms = listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS).all { ContextCompat.checkSelfPermission(this@MainActivity, it) == PackageManager.PERMISSION_GRANTED }
                        if (isDefault) viewModel.syncSms()
                    }
                }
                lifecycle.addObserver(observer)
                onDispose { lifecycle.removeObserver(observer) }
            }
            NexaTheme(settings) {
                Column(Modifier.fillMaxSize()) {
                    if (!isDefault || !hasSms) Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.statusBarsPadding()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("SMS por tu operadora. Esta versión todavía no descarga MMS ni envía mensajes por Internet.")
                            Button(onClick = {
                                if (isDefault) requestPermissions()
                                else if (Build.VERSION.SDK_INT >= 29) {
                                    val manager = getSystemService(RoleManager::class.java)
                                    if (manager.isRoleAvailable(RoleManager.ROLE_SMS)) role.launch(manager.createRequestRoleIntent(RoleManager.ROLE_SMS))
                                } else {
                                    role.launch(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName))
                                }
                            }) { Text(if(isDefault) "Conceder permisos SMS" else "Usar como aplicación SMS") }
                        }
                    }
                    status?.let { message ->
                        Surface(color = MaterialTheme.colorScheme.errorContainer) {
                            Row(Modifier.padding(12.dp)) {
                                Text(message, Modifier.weight(1f))
                                TextButton(onClick = viewModel::clearStatusBanner) { Text("Cerrar") }
                            }
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        NexaNavigation(viewModel, incomingIntent) { incomingIntent = null }
                    }
                }
            }
        }
    }
}
