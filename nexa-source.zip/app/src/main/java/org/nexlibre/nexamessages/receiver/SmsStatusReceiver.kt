package org.nexlibre.nexamessages.receiver

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Telephony
import androidx.room.withTransaction
import kotlinx.coroutines.*
import org.nexlibre.nexamessages.data.local.*

class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("message_id", -1)
        val part = intent.getIntExtra("part", -1)
        val kind = intent.action ?: return
        if (id < 0 || part < 0 || kind !in listOf("sent", "delivered")) return
        val success = resultCode == Activity.RESULT_OK
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = NexaDatabase.getInstance(context)
                db.withTransaction {
                    val dao = db.nexaDao()
                    val message = dao.getMessage(id) ?: return@withTransaction
                    dao.insertPartResult(SmsPartResult(id, kind, part, success))
                    val results = dao.getPartResults(id)
                    val state = org.nexlibre.nexamessages.domain.model.reduceSmsResults(message.partCount, results)
                    dao.updateMessageStatus(id, state)
                    if (Telephony.Sms.getDefaultSmsPackage(context) == context.packageName) message.providerId?.let {
                        context.contentResolver.update(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, it.toString()),
                            ContentValues().apply {
                                put("type", when(state) { MessageStatus.FAILED -> 5; MessageStatus.SENDING -> 4; else -> 2 })
                                if (state == MessageStatus.DELIVERED) put("status", 0)
                            }, null, null)
                    }
                }
            } catch (error: Exception) {
                android.util.Log.e("NexaSMS", "SMS processing failed", error)
            } finally { pending.finish() }
        }
    }
}
