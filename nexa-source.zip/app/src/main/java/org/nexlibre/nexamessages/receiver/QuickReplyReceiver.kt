package org.nexlibre.nexamessages.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.RemoteInput
import kotlinx.coroutines.*
import org.nexlibre.nexamessages.data.local.NexaDatabase
import org.nexlibre.nexamessages.data.repository.*
import org.nexlibre.nexamessages.notifications.SmsNotifications

class QuickReplyReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val text = RemoteInput.getResultsFromIntent(intent)?.getCharSequence("reply_text")?.toString() ?: return
        val id = intent.getLongExtra("conversation_id", -1)
        val address = intent.getStringExtra("address") ?: return
        if (id < 0 || text.isBlank()) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = MessagingRepository(context, NexaDatabase.getInstance(context).nexaDao(), ContactsHelper(context))
                repo.sendSmsMessage(id, address, text).onSuccess { repo.markAsRead(id) }
                    .onFailure { SmsNotifications.show(context, id, address, "No se pudo enviar la respuesta: ${it.message}") }
            } catch (error: Exception) {
                android.util.Log.e("NexaSMS", "SMS processing failed", error)
            } finally { pending.finish() }
        }
    }
}
