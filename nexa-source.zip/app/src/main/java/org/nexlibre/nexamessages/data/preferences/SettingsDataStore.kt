package org.nexlibre.nexamessages.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.nexlibre.nexamessages.domain.model.*

private val Context.dataStore by preferencesDataStore(name = "nexa_settings")

class SettingsDataStore(private val context: Context) {

   companion object {
       private val KEY_SMS_SIM = intPreferencesKey("preferred_sms_subscription")
       private val KEY_UI_STYLE = stringPreferencesKey("ui_style")
       private val KEY_APPEARANCE = stringPreferencesKey("appearance_mode")
       private val KEY_DYNAMIC_COLORS = booleanPreferencesKey("use_dynamic_colors")
       private val KEY_ACCENT_PRESET = stringPreferencesKey("accent_preset")
       private val KEY_CHAT_BG = stringPreferencesKey("chat_bg")
       private val KEY_FONT_SCALE = floatPreferencesKey("font_scale")
       private val KEY_NOTIFICATIONS = booleanPreferencesKey("notifications_enabled")
       private val KEY_NOTIFICATION_PREVIEW = booleanPreferencesKey("notification_preview")
   }

   val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
       UserSettings(
           uiStyle = runCatching {
               UiStyle.valueOf(prefs[KEY_UI_STYLE] ?: UiStyle.GOOGLE.name)
           }.getOrDefault(UiStyle.GOOGLE),
           appearanceMode = runCatching {
               AppearanceMode.valueOf(prefs[KEY_APPEARANCE] ?: AppearanceMode.SYSTEM.name)
           }.getOrDefault(AppearanceMode.SYSTEM),
           useDynamicColors = prefs[KEY_DYNAMIC_COLORS] ?: true,
           accentPreset = runCatching {
               AccentPreset.valueOf(prefs[KEY_ACCENT_PRESET] ?: AccentPreset.NEXA_BLUE.name)
           }.getOrDefault(AccentPreset.NEXA_BLUE),
           chatBackground = runCatching {
               ChatBackgroundPreset.valueOf(prefs[KEY_CHAT_BG] ?: ChatBackgroundPreset.DEFAULT.name)
           }.getOrDefault(ChatBackgroundPreset.DEFAULT),
           fontScale = prefs[KEY_FONT_SCALE] ?: 1.0f,
           notificationsEnabled = prefs[KEY_NOTIFICATIONS] ?: true,
           previewInNotifications = prefs[KEY_NOTIFICATION_PREVIEW] ?: true,
           preferredSmsSubscriptionId = prefs[KEY_SMS_SIM] ?: SIM_SYSTEM
       )
   }

   suspend fun updateUiStyle(style: UiStyle) {
       context.dataStore.edit { it[KEY_UI_STYLE] = style.name }
   }

   suspend fun updateAppearance(mode: AppearanceMode) {
       context.dataStore.edit { it[KEY_APPEARANCE] = mode.name }
   }

   suspend fun updateDynamicColors(enabled: Boolean) {
       context.dataStore.edit { it[KEY_DYNAMIC_COLORS] = enabled }
   }

   suspend fun updateAccentPreset(preset: AccentPreset) {
       context.dataStore.edit { it[KEY_ACCENT_PRESET] = preset.name }
   }

      suspend fun updateChatBackground(bg: ChatBackgroundPreset) {
          context.dataStore.edit { it[KEY_CHAT_BG] = bg.name }
      }

      suspend fun updateFontScale(scale: Float) {
          context.dataStore.edit { it[KEY_FONT_SCALE] = scale.coerceIn(0.85f, 1.35f) }
      }

      suspend fun updateNotifications(enabled: Boolean) {
          context.dataStore.edit { it[KEY_NOTIFICATIONS] = enabled }
      }

      suspend fun updateNotificationPreview(enabled: Boolean) {
          context.dataStore.edit { it[KEY_NOTIFICATION_PREVIEW] = enabled }
      }

    fun conversationSimFlow(id: Long): Flow<Int> = context.dataStore.data.map {
        it[intPreferencesKey("sms_sim_chat_$id")] ?: SIM_INHERIT
    }
    suspend fun setPreferredSmsSim(id: Int) {
        require(id == SIM_SYSTEM || id >= 0)
        context.dataStore.edit { it[KEY_SMS_SIM] = id }
    }
    suspend fun setConversationSmsSim(conversationId: Long, id: Int) {
        require(id == SIM_INHERIT || id == SIM_SYSTEM || id >= 0)
        context.dataStore.edit {
            val key = intPreferencesKey("sms_sim_chat_$conversationId")
            if (id == SIM_INHERIT) it.remove(key) else it[key] = id
        }
    }
}
