package org.nexlibre.nexamessages.data.repository

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.nexlibre.nexamessages.domain.model.ContactItem

class ContactsHelper(private val context: Context) {

   fun hasContactsPermission(): Boolean {
       return ContextCompat.checkSelfPermission(
           context,
           Manifest.permission.READ_CONTACTS
       ) == PackageManager.PERMISSION_GRANTED
   }

   suspend fun loadDeviceContacts(): List<ContactItem> = withContext(Dispatchers.IO) {
       if (!hasContactsPermission()) return@withContext emptyList()

       val contacts = mutableListOf<ContactItem>()
       val seenNumbers = mutableSetOf<String>()

       val projection = arrayOf(
           ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
           ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY,
           ContactsContract.CommonDataKinds.Phone.NUMBER
       )

       context.contentResolver.query(
           ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
           projection,
           null,
           null,
           "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY} ASC"
       )?.use { cursor ->
           val idIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
           val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY)
           val numberIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)

           while (cursor.moveToNext()) {
               val id = cursor.getString(idIdx) ?: continue
               val name = cursor.getString(nameIdx) ?: "Sin nombre"
               val rawNumber = cursor.getString(numberIdx) ?: continue
               val normalized = normalizePhoneNumber(rawNumber)

               if (normalized.isNotBlank() && seenNumbers.add(normalized)) {
                   contacts.add(
                       ContactItem(
                           id = id,
                           name = name,
                           phoneNumber = rawNumber.trim()
                       )
                   )
               }
           }
       }
       contacts

     }

     suspend fun resolveContactName(address: String): String? = withContext(Dispatchers.IO) {
         if (!hasContactsPermission()) return@withContext null
         val uri = android.net.Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(address))
         context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
             if (it.moveToFirst()) it.getString(0) else null
         }
     }

     companion object {
         fun normalizePhoneNumber(input: String): String {
             return input.replace(Regex("[^0-9+]"), "")
         }
     }
}
