package org.nexlibre.nexamessages.domain.model

import org.nexlibre.nexamessages.data.local.MessageStatus
import org.nexlibre.nexamessages.data.local.SmsPartResult

/** Delivery reports are optional: failed delivery is not a failed submission. */
fun reduceSmsResults(partCount: Int, results: List<SmsPartResult>): MessageStatus = when {
    results.any { it.kind == "sent" && !it.success } -> MessageStatus.FAILED
    results.count { it.kind == "delivered" && it.success } == partCount -> MessageStatus.DELIVERED
    results.count { it.kind == "sent" && it.success } == partCount -> MessageStatus.SENT
    else -> MessageStatus.SENDING
}
