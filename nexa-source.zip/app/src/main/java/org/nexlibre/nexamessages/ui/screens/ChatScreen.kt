package org.nexlibre.nexamessages.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.data.local.ConversationEntity
import org.nexlibre.nexamessages.data.local.MessageEntity
import org.nexlibre.nexamessages.data.local.MessageStatus
import org.nexlibre.nexamessages.domain.model.UiStyle
import org.nexlibre.nexamessages.ui.theme.LocalNexaStyle
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    conversation: ConversationEntity?,
    messages: List<MessageEntity>,
    statusBanner: String?,
    onDismissBanner: () -> Unit,
    onSendMessage: (String, (Boolean) -> Unit) -> Unit,
    onBack: () -> Unit,
    simSelector: @Composable () -> Unit = {}
) {
    val style = LocalNexaStyle.current
    val isIos = style.uiStyle == UiStyle.IOS
    var draftText by androidx.compose.runtime.saveable.rememberSaveable(conversation?.id) { mutableStateOf("") }
    var submitting by remember { mutableStateOf(false) }
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    LaunchedEffect(messages.size) { if(messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex) }


   val titleText = conversation?.contactName?.takeIf { it.isNotBlank() }
       ?: conversation?.address
       ?: "Chat"

   Scaffold(
       containerColor = style.chatCanvasBackground,
       topBar = {
           TopAppBar(
               colors = TopAppBarDefaults.topAppBarColors(
                   containerColor = MaterialTheme.colorScheme.surface
               ),
               navigationIcon = {
                   IconButton(onClick = onBack) {
                       Icon(
                           imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                           contentDescription = "Volver",
                           tint = if (isIos) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                       )
                   }

       },
       title = {
           Column {
               Text(
                   text = titleText,
                   style = MaterialTheme.typography.titleMedium,
                   fontWeight = FontWeight.Bold
               )
               if (conversation?.contactName != null) {
                   Text(
                       text = conversation.address,
                       style = MaterialTheme.typography.labelSmall,
                       color = MaterialTheme.colorScheme.onSurfaceVariant
                   )
               }
           }
       }
    )
},
bottomBar = {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = if (isIos) 0.dp else 3.dp
    ) {
        Column {
        simSelector()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = draftText,
                onValueChange = { draftText = it },
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(if (isIos) "Mensaje de texto • SMS" else "Mensaje SMS")
                },
                maxLines = 4,
                shape = CircleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    focusedBorderColor = if (isIos) MaterialTheme.colorScheme.outlineVariant else MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                )
            )

           Spacer(modifier = Modifier.width(8.dp))

           IconButton(
               onClick = {
                   if (draftText.isNotBlank()) {
                       submitting = true
                       onSendMessage(draftText) { accepted ->
                           if (accepted) draftText = ""
                           submitting = false
                       }
                   }
               },
               enabled = draftText.isNotBlank() && !submitting,
               modifier = Modifier
                   .size(44.dp)

                        .clip(CircleShape)
                        .background(
                            if (draftText.isNotBlank()) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
               ) {
                     Icon(
                         imageVector = if (isIos) Icons.Default.ArrowUpward else Icons.AutoMirrored.Filled.Send,
                         contentDescription = "Enviar SMS",
                         tint = if (draftText.isNotBlank()) MaterialTheme.colorScheme.onPrimary
                         else MaterialTheme.colorScheme.onSurfaceVariant
                     )
               }
           }
        }
        }
    }
) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
    ) {
        if (statusBanner != null) {
            Surface(
                color = MaterialTheme.colorScheme.errorContainer,
                contentColor = MaterialTheme.colorScheme.onErrorContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.ErrorOutline, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = statusBanner,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onDismissBanner) {
                        Text("OK")
                    }
                }
            }
        }

       LazyColumn(
           state = listState,
           modifier = Modifier
               .fillMaxSize()
               .padding(horizontal = 12.dp),
           contentPadding = PaddingValues(vertical = 12.dp),
           verticalArrangement = Arrangement.spacedBy(8.dp)
       ) {
           items(messages, key = { it.id }) { msg ->
               MessageBubbleItem(
                   message = msg,
                   isIos = isIos
               )
           }
       }
   }

    }
}

@Composable
private fun MessageBubbleItem(
    message: MessageEntity,
    isIos: Boolean
) {
    val style = LocalNexaStyle.current
    val isOutgoing = !message.isIncoming
    val timeText = remember(message.timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.timestamp))
    }

    val bubbleShape = if (isIos) {
        RoundedCornerShape(
            topStart = 18.dp,
            topEnd = 18.dp,
            bottomStart = if (isOutgoing) 18.dp else 4.dp,
            bottomEnd = if (isOutgoing) 4.dp else 18.dp
        )
    } else {
        RoundedCornerShape(
            topStart = 22.dp,
            topEnd = 22.dp,
            bottomStart = if (isOutgoing) 22.dp else 6.dp,
            bottomEnd = if (isOutgoing) 6.dp else 22.dp
        )
    }

    val bubbleColor = if (isOutgoing) style.outgoingBubbleColor else style.incomingBubbleColor
    val textColor = if (isOutgoing) style.outgoingTextColor else style.incomingTextColor

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isOutgoing) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = bubbleColor,
            contentColor = textColor,
            shape = bubbleShape,
            modifier = Modifier.widthIn(max = 300.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Text(
                    text = message.body,
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        val statusLabel = when (message.status) {
            MessageStatus.SENDING -> "Enviando..."
            MessageStatus.SENT -> "Enviado • $timeText"
            MessageStatus.DELIVERED -> "Entregado • $timeText"
            MessageStatus.FAILED -> "No enviado (revisar SIM/permiso) • $timeText"
            MessageStatus.RECEIVED -> timeText
        }

          Text(
              text = statusLabel,
              style = MaterialTheme.typography.labelSmall,
              color = if (message.status == MessageStatus.FAILED) {
                  MaterialTheme.colorScheme.error
              } else {
                  MaterialTheme.colorScheme.onSurfaceVariant
              },
              modifier = Modifier.padding(horizontal = 4.dp)
          )
     }
}
