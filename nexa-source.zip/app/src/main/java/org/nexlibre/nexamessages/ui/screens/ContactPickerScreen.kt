package org.nexlibre.nexamessages.ui.screens

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.domain.model.ContactItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactPickerScreen(
    contacts: List<ContactItem>,
    onRequestRefreshContacts: () -> Unit,
    onSelectContact: (ContactItem) -> Unit,
    onBack: () -> Unit
) {
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) onRequestRefreshContacts()
    }

   LaunchedEffect(Unit) {
       onRequestRefreshContacts()
   }

   Scaffold(
       containerColor = MaterialTheme.colorScheme.background,
       topBar = {
           TopAppBar(
               title = { Text("Seleccionar contacto") },
               navigationIcon = {
                   IconButton(onClick = onBack) {
                       Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver")
                   }
               }
           )
       }
   ) { padding ->
       if (contacts.isEmpty()) {
           Column(
               modifier = Modifier
                   .fillMaxSize()
                   .padding(padding)
                   .padding(24.dp),
               verticalArrangement = Arrangement.Center,

         horizontalAlignment = Alignment.CenterHorizontally
   ) {
         Icon(
             imageVector = Icons.Default.Contacts,
             contentDescription = null,
             modifier = Modifier.size(56.dp),
             tint = MaterialTheme.colorScheme.primary
         )
         Spacer(modifier = Modifier.height(16.dp))
         Text(
             text = "Acceso a Contactos del Dispositivo",
             style = MaterialTheme.typography.titleMedium,
             fontWeight = FontWeight.Bold
         )
         Spacer(modifier = Modifier.height(8.dp))
         Text(
             text = "Permite leer contactos para elegir un destinatario de tu agenda.",
             style = MaterialTheme.typography.bodyMedium,
             color = MaterialTheme.colorScheme.onSurfaceVariant
         )
         Spacer(modifier = Modifier.height(20.dp))
         Button(
             onClick = { permissionLauncher.launch(Manifest.permission.READ_CONTACTS) }
         ) {
             Text("Permitir lectura de contactos")
         }
    }
} else {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
    ) {
        items(contacts, key = { "${it.id}_${it.phoneNumber}" }) { contact ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectContact(contact) }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = contact.name.firstOrNull()?.uppercase() ?: "#",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = contact.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold
                    )

                                         Text(
                                             text = contact.phoneNumber,
                                             style = MaterialTheme.typography.bodySmall,
                                             color = MaterialTheme.colorScheme.onSurfaceVariant
                                         )
                                  }
                              }
                              HorizontalDivider( thickness = 0.5.dp)
                        }
                   }
              }
        }
}
