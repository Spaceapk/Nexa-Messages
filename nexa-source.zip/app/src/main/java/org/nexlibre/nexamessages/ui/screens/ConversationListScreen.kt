package org.nexlibre.nexamessages.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.data.local.ConversationEntity
import org.nexlibre.nexamessages.domain.model.UiStyle
import org.nexlibre.nexamessages.ui.theme.LocalNexaStyle
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConversationListScreen(
    conversations: List<ConversationEntity>,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onOpenConversation: (Long) -> Unit,
    onComposeNew: () -> Unit,
    onOpenContacts: () -> Unit,
    onOpenSettings: () -> Unit,
    onDeleteConversation: (Long) -> Unit
) {
    val style = LocalNexaStyle.current
    val isIos = style.uiStyle == UiStyle.IOS
    var pendingDelete by remember { mutableStateOf<Long?>(null) }
    pendingDelete?.let { id ->
        AlertDialog(onDismissRequest = { pendingDelete = null },
            title = { Text("¿Eliminar conversación?") },
            text = { Text("Se eliminarán sus SMS de Nexa Messages y del historial de Android.") },
            confirmButton = { TextButton(onClick = { onDeleteConversation(id); pendingDelete = null }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancelar") } })
    }

   Scaffold(
       containerColor = MaterialTheme.colorScheme.background,
       topBar = {
           TopAppBar(
               colors = TopAppBarDefaults.topAppBarColors(
                   containerColor = MaterialTheme.colorScheme.background,
                   titleContentColor = MaterialTheme.colorScheme.onBackground
               ),
               title = {
                   Text(
                       text = if (isIos) "Mensajes" else "Nexa Messages",
                       style = if (isIos) {
                           MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                       } else {
                           MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold)
                       }
                   )
               },
               actions = {

               IconButton(onClick = onOpenContacts) {
                   Icon(
                       imageVector = Icons.Default.Contacts,
                       contentDescription = "Contactos",
                       tint = if (isIos) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                   )
               }
               if (isIos) {
                   // En iOS el botón de redactar se ubica en la barra superior derecha
                   IconButton(onClick = onComposeNew) {
                       Icon(
                           imageVector = Icons.Outlined.Edit,
                           contentDescription = "Nuevo mensaje",
                           tint = MaterialTheme.colorScheme.primary
                       )
                   }
               }
               IconButton(onClick = onOpenSettings) {
                   Icon(
                       imageVector = Icons.Outlined.Settings,
                       contentDescription = "Ajustes",
                       tint = if (isIos) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                   )
               }
           }
       )
    },
    floatingActionButton = {
        // En estilo Google Material 3 usamos un ExtendedFloatingActionButton tipo píldora
        if (!isIos) {
            ExtendedFloatingActionButton(
                onClick = onComposeNew,
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                text = { Text("Iniciar chat") }
            )
        }
    }
) { padding ->
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
    ) {
        // Barra de búsqueda
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = {
                Text(if (isIos) "Buscar" else "Buscar conversaciones o números...")
            },
            leadingIcon = {
                Icon(Icons.Default.Search, contentDescription = null)
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {

                       IconButton(onClick = { onSearchQueryChange("") }) {
                           Icon(Icons.Default.Clear, contentDescription = "Limpiar búsqueda")
                       }
                    }
                },
                singleLine = true,
                shape = if (isIos) RoundedCornerShape(10.dp) else CircleShape,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent
                )
            )

            if (conversations.isEmpty()) {
                EmptyConversationsState(
                    isIos = isIos,
                    onComposeNew = onComposeNew
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        horizontal = if (isIos) 0.dp else 12.dp,
                        vertical = 8.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(if (isIos) 0.dp else 8.dp)
                ) {
                    items(conversations, key = { it.id }) { conversation ->
                        ConversationRowItem(
                            conversation = conversation,
                            isIos = isIos,
                            onClick = { onOpenConversation(conversation.id) },
                            onDelete = { pendingDelete = conversation.id }
                        )
                        if (isIos) {
                            HorizontalDivider(
                                modifier = Modifier.padding(start = 76.dp),
                                thickness = 0.5.dp,
                                color = MaterialTheme.colorScheme.surfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConversationRowItem(
    conversation: ConversationEntity,
    isIos: Boolean,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val displayName = conversation.contactName?.takeIf { it.isNotBlank() } ?: conversation.address
    val initial = displayName.firstOrNull()?.uppercaseChar()?.toString() ?: "#"
    val formattedTime = remember(conversation.lastMessageTimestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(conversation.lastMessageTimestamp))

}

val rowContent: @Composable () -> Unit = {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Punto azul de no leído al estilo iOS a la izquierda del avatar
        if (isIos && conversation.unreadCount > 0) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            )
            Spacer(modifier = Modifier.width(8.dp))
        }

       // Avatar circular sólido
       Box(
           modifier = Modifier
               .size(48.dp)
               .clip(CircleShape)
               .background(
                   if (isIos) MaterialTheme.colorScheme.surfaceVariant
                   else MaterialTheme.colorScheme.primaryContainer
               ),
           contentAlignment = Alignment.Center
       ) {
           Text(
               text = initial,
               style = MaterialTheme.typography.titleMedium,
               fontWeight = FontWeight.Bold,
               color = if (isIos) MaterialTheme.colorScheme.onSurfaceVariant
               else MaterialTheme.colorScheme.onPrimaryContainer
           )
       }

       Spacer(modifier = Modifier.width(14.dp))

       Column(modifier = Modifier.weight(1f)) {
           Row(
               modifier = Modifier.fillMaxWidth(),
               horizontalArrangement = Arrangement.SpaceBetween,
               verticalAlignment = Alignment.CenterVertically
           ) {
               Text(
                   text = displayName,
                   style = MaterialTheme.typography.titleMedium,
                   fontWeight = if (conversation.unreadCount > 0) FontWeight.Bold else FontWeight.SemiBold,
                   maxLines = 1,
                   overflow = TextOverflow.Ellipsis,
                   modifier = Modifier.weight(1f)
               )
               Text(
                   text = formattedTime,
                   style = MaterialTheme.typography.labelMedium,
                   color = MaterialTheme.colorScheme.onSurfaceVariant

                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = conversation.lastMessagePreview,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (conversation.unreadCount > 0) {
                        MaterialTheme.colorScheme.onSurface
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    },
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Eliminar conversación",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (isIos) {
        Surface(color = MaterialTheme.colorScheme.background) {
            rowContent()
        }
    } else {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
            )
        ) {
            rowContent()
        }
    }
}

@Composable
private fun EmptyConversationsState(
    isIos: Boolean,
    onComposeNew: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Forum,
            contentDescription = null,
            modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.primary

           )
           Spacer(modifier = Modifier.height(16.dp))
           Text(
               text = "Sin conversaciones activas",
               style = MaterialTheme.typography.titleLarge,
               fontWeight = FontWeight.Bold
           )
           Spacer(modifier = Modifier.height(8.dp))
           Text(
               text = "Tus mensajes SMS se guardan en este dispositivo.",
               style = MaterialTheme.typography.bodyMedium,
               color = MaterialTheme.colorScheme.onSurfaceVariant
           )
           Spacer(modifier = Modifier.height(24.dp))
           Button(
               onClick = onComposeNew,
               shape = if (isIos) RoundedCornerShape(10.dp) else CircleShape
           ) {
               Icon(Icons.Default.Add, contentDescription = null)
               Spacer(modifier = Modifier.width(8.dp))
               Text("Redactar primer mensaje")
           }
     }
}
