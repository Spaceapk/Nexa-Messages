package org.nexlibre.nexamessages.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.first
import org.nexlibre.nexamessages.MainActivity
import org.nexlibre.nexamessages.R
import org.nexlibre.nexamessages.data.preferences.SettingsDataStore
import org.nexlibre.nexamessages.receiver.QuickReplyReceiver

object SmsNotifications {
    suspend fun show(context: Context, id: Long, address: String, body: String) {
        val settings = SettingsDataStore(context).settingsFlow.first()
        if (!settings.notificationsEnabled) return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context,
                Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel("sms", "Mensajes SMS", NotificationManager.IMPORTANCE_HIGH))
        val open = Intent(context, MainActivity::class.java).putExtra("conversation_id", id)
            .setData(Uri.parse("nexa://chat/$id"))
        val content = PendingIntent.getActivity(context, id.toInt(), open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val reply = PendingIntent.getBroadcast(context, id.toInt(),
            Intent(context, QuickReplyReceiver::class.java).setAction("reply")
                .setData(Uri.parse("nexa://reply/$id")).putExtra("conversation_id", id).putExtra("address", address),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val notification = NotificationCompat.Builder(context, "sms")
            .setSmallIcon(R.drawable.ic_message).setContentTitle(if(settings.previewInNotifications) address else "Nexa Messages")
            .setContentText(if(settings.previewInNotifications) body else "Nuevo SMS")
            .setContentIntent(content).setAutoCancel(true).setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setVisibility(if(settings.previewInNotifications) NotificationCompat.VISIBILITY_PRIVATE else NotificationCompat.VISIBILITY_SECRET)
        if (id > 0) notification.addAction(NotificationCompat.Action.Builder(0, "Responder", reply)
                .addRemoteInput(RemoteInput.Builder("reply_text").setLabel("Respuesta SMS").build())
                .setAuthenticationRequired(true).build())
        NotificationManagerCompat.from(context).notify(id.toInt(), notification.build())
    }
}
