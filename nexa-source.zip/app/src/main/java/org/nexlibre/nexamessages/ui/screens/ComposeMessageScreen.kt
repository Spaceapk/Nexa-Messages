package org.nexlibre.nexamessages.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.nexlibre.nexamessages.domain.model.UiStyle
import org.nexlibre.nexamessages.ui.theme.LocalNexaStyle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposeMessageScreen(
    prefilledAddress: String = "",
    prefilledName: String? = null,
    prefilledBody: String = "",
    onPickContact: () -> Unit,
    onStartChat: (address: String, name: String?, body: String) -> Unit,
    onBack: () -> Unit,
    simSelector: @Composable () -> Unit = {}
) {
    val style = LocalNexaStyle.current
    val isIos = style.uiStyle == UiStyle.IOS

   var recipientAddress by androidx.compose.runtime.saveable.rememberSaveable(prefilledAddress) { mutableStateOf(prefilledAddress) }
   var messageBody by androidx.compose.runtime.saveable.rememberSaveable(prefilledBody) { mutableStateOf(prefilledBody) }

   Scaffold(
       containerColor = MaterialTheme.colorScheme.background,
       topBar = {
           TopAppBar(
               title = { Text(if (isIos) "Nuevo mensaje" else "Redactar SMS") },
               navigationIcon = {
                   IconButton(onClick = onBack) {
                       Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancelar")
                   }
               }
           )
       }
   ) { padding ->
       Column(
           modifier = Modifier
               .fillMaxSize()
               .padding(padding)
               .padding(16.dp),
           verticalArrangement = Arrangement.spacedBy(16.dp)
       ) {
           simSelector()
           Row(
               modifier = Modifier.fillMaxWidth(),
               verticalAlignment = Alignment.CenterVertically
           ) {
               OutlinedTextField(
                   value = recipientAddress,
                   onValueChange = { recipientAddress = it },

                    modifier = Modifier.weight(1f),
                    label = {
                        Text(
                            if (!prefilledName.isNullOrBlank()) "Para: $prefilledName"
                            else "Número de teléfono"
                        )
                    },
                    placeholder = { Text("+505 8888 8888") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    shape = if (isIos) RoundedCornerShape(10.dp) else CircleShape
                )

                Spacer(modifier = Modifier.width(8.dp))

                FilledTonalIconButton(onClick = onPickContact) {
                    Icon(Icons.Default.PersonAdd, contentDescription = "Elegir de Contactos")
                }
            }

            OutlinedTextField(
                value = messageBody,
                onValueChange = { messageBody = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = { Text("Escribe tu mensaje SMS...") },
                shape = RoundedCornerShape(if (isIos) 12.dp else 20.dp)
            )

            Button(
                onClick = {
                    onStartChat(recipientAddress.trim(), prefilledName, messageBody.trim())
                },
                enabled = recipientAddress.isNotBlank(),
                modifier = Modifier.fillMaxWidth(),
                shape = if (isIos) RoundedCornerShape(12.dp) else CircleShape
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (messageBody.isBlank()) "Abrir conversación" else "Enviar SMS")
            }
        }
    }
}
