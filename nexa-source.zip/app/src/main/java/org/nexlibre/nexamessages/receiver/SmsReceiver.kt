package org.nexlibre.nexamessages.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.*
import org.nexlibre.nexamessages.data.local.NexaDatabase
import org.nexlibre.nexamessages.data.repository.*
import org.nexlibre.nexamessages.notifications.SmsNotifications

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        if (messages.isNullOrEmpty()) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repository = MessagingRepository(context, NexaDatabase.getInstance(context).nexaDao(), ContactsHelper(context))
                messages.groupBy { it.displayOriginatingAddress ?: "Desconocido" }.forEach { (sender, parts) ->
                    val body = parts.joinToString("") { it.displayMessageBody ?: "" }
                    val id = repository.recordIncomingSms(sender, body, parts.first().timestampMillis,
                        intent.getIntExtra("subscription", -1))
                    SmsNotifications.show(context, id, sender, body)
                }
            } catch (error: Exception) {
                android.util.Log.e("NexaSMS", "SMS processing failed", error)
            } finally { pending.finish() }
        }
    }
}
