package org.nexlibre.nexamessages.data.repository

import android.Manifest
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import org.nexlibre.nexamessages.data.preferences.SettingsDataStore
import org.nexlibre.nexamessages.domain.model.*
import kotlinx.coroutines.withContext
import org.nexlibre.nexamessages.data.local.*
import org.nexlibre.nexamessages.receiver.SmsStatusReceiver

class MessagingRepository(private val context: Context, private val dao: NexaDao,
                          private val contactsHelper: ContactsHelper) {
    private val database get() = NexaDatabase.getInstance(context)
    fun observeConversations() = dao.observeConversations()
    fun searchConversations(query: String) = dao.searchConversations(query)
    fun observeConversation(id: Long) = dao.observeConversationById(id)
    fun observeMessages(id: Long) = dao.observeMessages(id)
    fun isDefault() = Telephony.Sms.getDefaultSmsPackage(context) == context.packageName
    private fun requireDefault() {
        check(isDefault()) { "Selecciona Nexa Messages como aplicación SMS predeterminada." }
    }
    suspend fun getOrCreateConversation(rawAddress: String, explicitContactName: String? = null): Long =
        withContext(Dispatchers.IO) {
            val address = ContactsHelper.normalizePhoneNumber(rawAddress).ifBlank { rawAddress.trim() }
            require(address.isNotBlank()) { "Escribe un destinatario." }
            val name = explicitContactName ?: contactsHelper.resolveContactName(address)
            database.withTransaction {
                dao.getConversationByAddress(address)?.id ?: dao.insertConversation(
                    ConversationEntity(address = address, contactName = name,
                        lastMessagePreview = "", lastMessageTimestamp = System.currentTimeMillis()))
            }
        }
    suspend fun sendSmsMessage(conversationId: Long, destinationAddress: String, body: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            var messageId: Long? = null
            var providerUri: Uri? = null
            try {
                requireDefault()
                require(body.isNotBlank()) { "El mensaje está vacío." }
                require(destinationAddress.matches(Regex("[+0-9 ()-]+"))) { "Número no válido para enviar SMS." }
                check(ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    "Concede el permiso para enviar SMS."
                }
                val preferences = SettingsDataStore(context)
                val chatChoice = preferences.conversationSimFlow(conversationId).first()
                val preferred = if (chatChoice == SIM_INHERIT) preferences.settingsFlow.first().preferredSmsSubscriptionId else chatChoice
                val activeSims = SimRepository(context).loadActiveSims()
                val subscription = resolveSmsSubscription(preferred, SubscriptionManager.getDefaultSmsSubscriptionId(),
                    activeSims?.map { it.subscriptionId })
                val manager = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java).createForSubscriptionId(subscription)
                              else @Suppress("DEPRECATION") SmsManager.getSmsManagerForSubscriptionId(subscription)
                val parts = manager.divideMessage(body)
                val now = System.currentTimeMillis()
                providerUri = context.contentResolver.insert(Telephony.Sms.CONTENT_URI, ContentValues().apply {
                    put("address", destinationAddress); put("body", body); put("date", now)
                    put("type", Telephony.Sms.MESSAGE_TYPE_OUTBOX); put("read", 1); put("sub_id", subscription)
                }) ?: error("No se pudo guardar el SMS en Android.")
                val id = database.withTransaction {
                    val id = dao.insertMessage(MessageEntity(conversationId = conversationId, senderAddress = "Yo", body = body,
                        timestamp = now, isIncoming = false, status = MessageStatus.SENDING,
                        providerId = providerUri!!.lastPathSegment!!.toLong(), partCount = parts.size))
                    dao.getConversationByAddress(ContactsHelper.normalizePhoneNumber(destinationAddress))?.let {
                        dao.updateConversation(it.copy(lastMessagePreview = body, lastMessageTimestamp = now))
                    }
                    id
                }
                messageId = id
                fun callback(kind: String, part: Int): PendingIntent {
                    val intent = Intent(context, SmsStatusReceiver::class.java)
                        .setAction(kind).setData(Uri.parse("nexa://sms/$id/$kind/$part"))
                        .putExtra("message_id", id).putExtra("part", part)
                    return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                }
                val sent = ArrayList(parts.indices.map { callback("sent", it) })
                val delivered = ArrayList(parts.indices.map { callback("delivered", it) })
                manager.sendMultipartTextMessage(destinationAddress, null, parts, sent, delivered)
                Result.success(Unit)
            } catch (e: Exception) {
                messageId?.let { dao.updateMessageStatus(it, MessageStatus.FAILED) }
                providerUri?.let { uri -> runCatching { context.contentResolver.update(uri, ContentValues().apply {
                    put("type", Telephony.Sms.MESSAGE_TYPE_FAILED)
                }, null, null) } }
                Result.failure(e)
            }
        }
    suspend fun recordIncomingSms(senderAddress: String, body: String, timestamp: Long, subscriptionId: Int = -1): Long =
        withContext(Dispatchers.IO) {
            requireDefault()
            val uri = context.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
                put("address", senderAddress); put("body", body); put("date", timestamp); put("read", 0)
                put("sub_id", subscriptionId)
            }) ?: error("No se pudo guardar el SMS recibido.")
            recordProviderMessage(uri.lastPathSegment!!.toLong(), senderAddress, body, timestamp, true, false, MessageStatus.RECEIVED)
        }
    private suspend fun recordProviderMessage(providerId: Long, address: String, body: String, timestamp: Long,
        incoming: Boolean, read: Boolean, status: MessageStatus): Long {
        val id = getOrCreateConversation(address)
        return database.withTransaction {
            if (dao.getMessageByProviderId(providerId) == null) {
                dao.insertMessage(MessageEntity(conversationId = id, senderAddress = address, body = body,
                    timestamp = timestamp, isIncoming = incoming, status = status, providerId = providerId))
                val conv = dao.getConversationByAddress(ContactsHelper.normalizePhoneNumber(address).ifBlank { address.trim() })!!
                dao.updateConversation(conv.copy(
                    lastMessagePreview = if (timestamp >= conv.lastMessageTimestamp || conv.lastMessagePreview.isEmpty()) body else conv.lastMessagePreview,
                    lastMessageTimestamp = if (conv.lastMessagePreview.isEmpty()) timestamp else maxOf(timestamp, conv.lastMessageTimestamp),
                    unreadCount = conv.unreadCount + if (incoming && !read) 1 else 0))
            }
            id
        }
    }
    suspend fun syncSms() = withContext(Dispatchers.IO) {
        if (!isDefault() || ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED) return@withContext
        context.contentResolver.query(Telephony.Sms.CONTENT_URI,
            arrayOf("_id", "address", "body", "date", "type", "read"), null, null, "date ASC")?.use { c ->
            while (c.moveToNext()) {
                val type = c.getInt(4)
                if (type == Telephony.Sms.MESSAGE_TYPE_DRAFT) continue
                recordProviderMessage(c.getLong(0), c.getString(1) ?: continue, c.getString(2) ?: "", c.getLong(3),
                    type == 1, c.getInt(5) == 1, when (type) {
                        1 -> MessageStatus.RECEIVED; 2 -> MessageStatus.SENT; 5 -> MessageStatus.FAILED
                        else -> MessageStatus.SENDING
                    })
            }
        }
    }
    suspend fun markAsRead(conversationId: Long) = withContext(Dispatchers.IO) {
        if (isDefault()) dao.getMessages(conversationId).filter { it.isIncoming }.forEach { m ->
            m.providerId?.let { context.contentResolver.update(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, it.toString()),
                ContentValues().apply { put("read", 1) }, null, null) }
        }
        dao.markConversationAsRead(conversationId)
        androidx.core.app.NotificationManagerCompat.from(context).cancel(conversationId.toInt())
    }
    suspend fun deleteConversation(conversationId: Long) = withContext(Dispatchers.IO) {
        requireDefault()
        dao.getMessages(conversationId).forEach { m -> m.providerId?.let {
            context.contentResolver.delete(Uri.withAppendedPath(Telephony.Sms.CONTENT_URI, it.toString()), null, null)
        } }
        database.withTransaction { dao.deletePartResults(conversationId); dao.deleteConversation(conversationId) }
    }
}
