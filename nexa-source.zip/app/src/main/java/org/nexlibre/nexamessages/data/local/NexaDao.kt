package org.nexlibre.nexamessages.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface NexaDao {

    @Query("""
        SELECT * FROM conversations
        WHERE isArchived = 0
        ORDER BY isPinned DESC, lastMessageTimestamp DESC
    """)
    fun observeConversations(): Flow<List<ConversationEntity>>

    @Query("""
        SELECT * FROM conversations
        WHERE contactName LIKE '%' || :query || '%'
           OR address LIKE '%' || :query || '%'
           OR lastMessagePreview LIKE '%' || :query || '%'
        ORDER BY lastMessageTimestamp DESC
    """)
    fun searchConversations(query: String): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id LIMIT 1")
    fun observeConversationById(id: Long): Flow<ConversationEntity?>

    @Query("SELECT * FROM conversations WHERE address = :normalizedAddress LIMIT 1")
    suspend fun getConversationByAddress(normalizedAddress: String): ConversationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: ConversationEntity): Long

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("DELETE FROM conversations WHERE id = :conversationId")
    suspend fun deleteConversation(conversationId: Long)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE id = :conversationId")
    suspend fun markConversationAsRead(conversationId: Long)

    @Query("""
        SELECT * FROM messages
        WHERE conversationId = :conversationId
        ORDER BY timestamp ASC
    """)
    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("UPDATE messages SET status = :status WHERE id = :messageId")
    suspend fun updateMessageStatus(messageId: Long, status: MessageStatus)

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun getMessage(id: Long): MessageEntity?
    @Query("SELECT * FROM messages WHERE providerId = :id LIMIT 1")
    suspend fun getMessageByProviderId(id: Long): MessageEntity?
    @Query("SELECT * FROM messages WHERE conversationId = :id")
    suspend fun getMessages(id: Long): List<MessageEntity>
    @Query("UPDATE messages SET providerId = :providerId WHERE id = :id")
    suspend fun setProviderId(id: Long, providerId: Long)
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPartResult(result: SmsPartResult)
    @Query("SELECT * FROM sms_results WHERE messageId = :id")
    suspend fun getPartResults(id: Long): List<SmsPartResult>
    @Query("DELETE FROM sms_results WHERE messageId IN (SELECT id FROM messages WHERE conversationId = :id)")
    suspend fun deletePartResults(id: Long)
}
