package org.nexlibre.nexamessages

import org.junit.Assert.assertEquals
import org.junit.Test
import org.nexlibre.nexamessages.domain.model.reduceSmsResults
import org.nexlibre.nexamessages.data.local.*

class SmsResultStateTest {
    private fun result(kind: String, part: Int, success: Boolean = true) = SmsPartResult(1, kind, part, success)
    @Test fun waitsForAllParts() {
        assertEquals(MessageStatus.SENDING, reduceSmsResults(2, listOf(result("sent", 0))))
        assertEquals(MessageStatus.SENT, reduceSmsResults(2, listOf(result("sent", 0), result("sent", 1))))
    }
    @Test fun oneSubmissionFailureFailsWholeMessage() {
        assertEquals(MessageStatus.FAILED, reduceSmsResults(2, listOf(result("sent", 0), result("sent", 1, false))))
    }
    @Test fun waitsForAllDeliveryReports() {
        assertEquals(MessageStatus.SENT, reduceSmsResults(2, listOf(result("sent", 0), result("sent", 1), result("delivered", 0))))
        assertEquals(MessageStatus.DELIVERED, reduceSmsResults(2, listOf(result("delivered", 0), result("delivered", 1))))
    }
    @Test fun failedDeliveryReportDoesNotInventSubmissionFailure() {
        assertEquals(MessageStatus.SENT, reduceSmsResults(1, listOf(result("sent", 0), result("delivered", 0, false))))
    }
    @Test fun noCallbackIsNotSuccess() {
        assertEquals(MessageStatus.SENDING, reduceSmsResults(1, emptyList()))
    }
}
