package org.nexlibre.nexamessages

import org.junit.Assert.assertEquals
import org.junit.Test
import org.nexlibre.nexamessages.domain.model.*

class SimSelectionTest {
    @Test fun selectedSubscriptionOverridesAndroidDefault() {
        assertEquals(42, resolveSmsSubscription(42, 17, listOf(17, 42)))
    }
    @Test fun androidDefaultIsUsedOnlyWhenRequested() {
        assertEquals(17, resolveSmsSubscription(SIM_SYSTEM, 17, listOf(17, 42)))
    }
    @Test(expected = IllegalStateException::class) fun removedSimNeverFallsBackToOtherSim() {
        resolveSmsSubscription(42, 17, listOf(17))
    }
    @Test(expected = IllegalStateException::class) fun ambiguousDualSimRequiresChoice() {
        resolveSmsSubscription(SIM_SYSTEM, -1, listOf(17, 42))
    }
    @Test fun singleActiveSimCanBeUsedWithoutAndroidDefault() {
        assertEquals(42, resolveSmsSubscription(SIM_SYSTEM, -1, listOf(42)))
    }
    @Test(expected = IllegalStateException::class) fun explicitChoiceRequiresPermissionToVerifySim() {
        resolveSmsSubscription(42, 17, null)
    }
    @Test fun systemChoiceStillWorksWithoutPhonePermission() {
        assertEquals(17, resolveSmsSubscription(SIM_SYSTEM, 17, null))
    }
    @Test(expected = IllegalStateException::class) fun inactiveSystemDefaultDoesNotSendOnUnknownSim() {
        resolveSmsSubscription(SIM_SYSTEM, 9, listOf(17, 42))
    }
}
