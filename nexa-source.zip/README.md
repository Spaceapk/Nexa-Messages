# Nexa Messages

Aplicación Android nativa recuperada del documento de 49 páginas, con Kotlin, Jetpack Compose, Room y DataStore. Paquete `org.nexlibre.nexamessages`. Android 8 o posterior.

## Primera versión de prueba SMS

- Temas Google Material 3 y iOS clásico con fondos sólidos, sin Liquid Glass.
- Claro, oscuro negro puro y seguir sistema; acentos, fondos y texto personalizables.
- Solicitud del rol SMS predeterminado y permisos. Importación del historial SMS del proveedor de Android al abrir la aplicación.
- Contactos reales, búsqueda local, conversaciones y eliminación confirmada del historial SMS.
- SMS mediante la SIM predeterminada de Android; mensajes largos en varias partes.
- Estados de envío por callbacks del sistema: no se declara enviado al llamar a SmsManager. Los informes de entrega dependen de la operadora.
- Notificaciones configurables y respuesta rápida; manejo de enlaces sms/smsto y respuestas a llamadas mediante RESPOND_VIA_MESSAGE.

## Límites de esta versión

MMS no implementado: el receptor informa de que la descarga no está disponible. **Esta versión no debe sustituir tu aplicación habitual si necesitas recibir MMS.** No hay mensajes por Internet, adjuntos, GIF, stickers, grupos por Internet, reacciones, respuestas citadas, programación, mensajes temporales, cifrado E2EE, llamadas ni videollamadas. Los campos de adjuntos y respuesta en Room son preparación de esquema, no funciones. Los SMS no tienen E2EE. La copia automática Android está desactivada; exportación y restauración todavía pendientes. Los emisores alfanuméricos pueden recibirse pero no usarse para enviar SMS.

Esta es una APK de prueba. Puedes elegir SIM 1 o SIM 2 desde ajustes, al redactar y dentro del chat. Pulsa «Mostrar SIM 1 y SIM 2» y concede el permiso Teléfono. La selección por conversación prevalece sobre la general. Los SMS pueden tener coste de operadora. Incluye selector de SIM general y por conversación; los envíos y respuestas rápidas usan la elección guardada. El historial sincroniza altas; cambios o borrados realizados por otras aplicaciones todavía no se reconcilian. El borrador puede perderse al cambiar de pantalla; la importación de historiales grandes todavía necesita pruebas de rendimiento.

## Compilación

JDK 17, Android SDK 35, Build Tools 34.0.0 (seleccionados por AGP) y Gradle 8.9. Se fijan AGP 8.7.3, Kotlin 2.0.21 y KSP 2.0.21-1.0.28 para conservar la base existente.

```sh
./gradlew testDebugUnitTest lintDebug assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
GitHub Actions ejecuta la misma comprobación y conserva la APK y los informes como artefactos. No se debe dar por ejecutado hasta que haya un run exitoso.

## Firma

La APK debug usa firma de desarrollo; **no es la firma permanente de publicación**. No se ha creado una clave estable. Antes de publicar, crear o recuperar una única clave permanente, guardar una copia privada y usar secretos de GitHub para el keystore y contraseñas. Nunca subir el keystore ni contraseñas al repositorio. Conservar esa clave en todas las actualizaciones estables. Las APK debug regeneradas por distintos entornos podrían no actualizarse entre sí.

## Continuidad

Ver `docs/RECOVERY.md`, `docs/ROADMAP.md` y `docs/DEVICE-TESTS.md`. No reconstruir la aplicación desde cero. Revisar las limitaciones documentadas antes de añadir funciones.

## Estado de GitHub

Repositorio encontrado: https://github.com/Spaceapk/Nexa-Messages (vacío al iniciar).
La integración devolvió HTTP 403 "Resource not accessible by integration" al crear README.md, tanto con la cuenta Spaceapk como con la conexión Primary. Git por HTTPS no dispone de credenciales de escritura. No se publicaron commits, no se ejecutó GitHub Actions y no hay artefacto remoto. La compilación y comprobaciones de esta entrega se realizan localmente. Publicar el código y comprobar Actions sigue pendiente de resolver el acceso.

## Actualización 0.1.1-alpha

Selector dual SIM con nombres de operadora y ranura real. Se guarda el identificador de suscripción, no el número de ranura. Si la SIM seleccionada desaparece o se revoca el permiso, se bloquea el envío; no se sustituye silenciosamente. La opción «Predeterminada de Android» conserva el comportamiento del sistema; si no existe predeterminada y solo hay una SIM activa se usa esa, pero con dos SIM se solicita elegir. No se solicitan números de teléfono ni identificadores privados de la SIM. La base Room no cambia: la actualización conserva mensajes y ajustes.

Pruebas específicas: ocho casos de resolución de SIM, además de cinco casos de estados de envío. La prueba con dos SIM físicas sigue pendiente. Esta APK conserva la misma firma debug que 0.1.0-alpha en este entorno para permitir actualización directa.
